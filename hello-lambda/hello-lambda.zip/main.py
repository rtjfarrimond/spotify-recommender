def get_handler(event, context):
    return {"message": "Hello world!"}
